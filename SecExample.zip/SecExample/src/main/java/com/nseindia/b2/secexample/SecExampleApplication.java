package com.nseindia.b2.secexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecExampleApplication.class, args);
	}

}
