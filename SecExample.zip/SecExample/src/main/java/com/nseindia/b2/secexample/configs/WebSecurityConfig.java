package com.nseindia.b2.secexample.configs;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.nseindia.b2.secexample.services.MyUserDetailsService;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
	
	@Autowired
	MyUserDetailsService uds;

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(uds);
		
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	// Authorizing HTTP request
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		// We are supposed to modify this http object
		// to inform spring security the authorization rules that we have.
		
		
		http.authorizeRequests()
		.antMatchers("/").permitAll()
		.antMatchers("/secureURL").authenticated().and()
		.formLogin();
		
		/*
		 * http .formLogin().loginPage("/login");
		 * 
		 * 
		 * http .authorizeRequests()
		 * .antMatchers("/","/insecureURL","/login").permitAll();
		 * 
		 * http .authorizeRequests() .antMatchers("/secureURL").authenticated();
		 * 
		 * http .authorizeRequests() .antMatchers("/**").denyAll();
		 */
		
	} // AUthorization config

}
