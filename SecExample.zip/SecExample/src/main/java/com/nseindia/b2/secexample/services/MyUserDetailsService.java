package com.nseindia.b2.secexample.services;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.nseindia.b2.secexample.models.MyUserDetails;

@Service
public class MyUserDetailsService implements UserDetailsService {

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		if(!username.equals("vijay")) {
			throw new UsernameNotFoundException("user not vijay");
		}
		return new MyUserDetails("vijay","$2a$10$BgZJFeKk/TbTvDM1wJKl..HNKlmb/zsLezuRkXSeMSiC9UdF5TbWa");
	}

}
