package com.nseindia.b2.webapp.repositories;

import org.springframework.data.repository.CrudRepository;

import com.nseindia.b2.webapp.entities.Author;

public interface Repository extends CrudRepository<Author, Long>{

}
